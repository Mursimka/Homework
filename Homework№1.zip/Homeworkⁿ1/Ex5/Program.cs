﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите ваше имя");
            string name = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Введите вашу фамилию");
            string surname = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Введите ваш город проживания");
            string city = Convert.ToString(Console.ReadLine());

            Console.WriteLine($"{name} {surname} {city}");
            Console.ReadKey();

        }
    }
}
