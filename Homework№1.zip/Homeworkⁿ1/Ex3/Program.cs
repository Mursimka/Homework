﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите х1");
            int x1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Введите х2");
            int x2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Введите y1");
            int y1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Введите y2");
            int y2 = int.Parse(Console.ReadLine());

            double r = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));

            Console.WriteLine("{0:F2}",r);
            Console.ReadKey();

        }
    }
}
