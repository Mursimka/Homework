﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите ваше имя");
            string name = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Введите вашу фамилию");
            string surname = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Введите ваш возраст");
            int age = int.Parse(Console.ReadLine());

            Console.WriteLine("Введите ваш рост");
            int height = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите ваш вес ");
            int weight = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine(name +" "+ surname + " " + age + " " + height + " " + weight);
            Console.WriteLine(name + " " + surname + " "+  "{0:N1}",age);
            Console.WriteLine($"{name} {surname} {age} {height} {weight}");
            Console.ReadKey();

        }
    }
}
