﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите вас вес");
            double weight = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите вас рост");
            double height = int.Parse(Console.ReadLine());

            double I = weight / (height * height);
            Console.WriteLine($"Ваш ИМТ = {I}");
            Console.ReadKey();
        }
    }
}
