﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX3
{
    public class Comparison
    {
        public static void myComparison()
        {
            Console.WriteLine("Введите первую строку");
            StringBuilder s1 = new StringBuilder(Console.ReadLine());
            Console.WriteLine("Введите вторую строку");
            StringBuilder s2 = new StringBuilder(Console.ReadLine());

            if (s1.Length == s2.Length)
            {
                if (s1.Equals(s2) == true)
                {
                    Console.WriteLine($"{s2} не является перестановкой {s1}");


                }
                else
                {
                    Console.WriteLine($"{s2} является перестановкой {s1}");
                }

            }
            else
            {
                Console.WriteLine("Строки не одной длины");
            }
        }
    }
}
