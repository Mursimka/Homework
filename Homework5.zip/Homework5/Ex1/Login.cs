﻿using System;

namespace Ex1
{
    partial class Program
    {
        class Login
        {
            public static void login()
            {
                int z = 0;
                int a = 0;
                string s = Console.ReadLine();
                char[] ss = s.ToCharArray();
                if (ss.Length==10)
                {
                    if (s[0] >= 'a' && s[0] <= 'z')
                    {

                        for (int i = 1; i <= 9; i++)
                        {
                            if (s[i] >= 'a' && s[i] <= 'z' || s[i] >= '0' && s[i] <= '9')
                            {
                                z++;
                                Console.WriteLine(z);
                            }
                        }
                        if (z == 9)
                        {
                            Console.WriteLine("Логин введен верно");
                        }

                    }
                    else { Console.WriteLine("Логин введен неверно: Первый символ не должен быть цифрой"); }
                }
                else { Console.WriteLine("Логин введен неверно: Должно быть 10 символов"); }

            }
        }
    }
}
