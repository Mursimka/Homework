﻿using System;

class Program
{
    static void Main()
    {
        string poems = "белеет парус одинокий в тумане моря голубом";
        char[] div = { ' ' };
        string[] parts = poems.Split(div);
        Console.WriteLine("Введите число букв в слове для вывода");
        int n = int.Parse(Console.ReadLine());
        string max = " ";
        for (int i = 0; i < parts.Length; i++)
        {
            if (parts[i].Length == n)
            {
                Console.WriteLine(parts[i]);
            }
        }
        for (int i = 0; i < parts.Length; i++)
        {

            if (parts[i].LastIndexOf("й") == parts.Length)
            {
                parts[i] = " ";
            }
        }
        for (int i = 0; i < parts.Length; i++)
        {
            if (max.Length < parts[i].Length )
            {
                max = parts[i];
            }
        }

        // собираем эти части в одну строку, в качестве разделителя используем символ |
        string str = String.Join(" ", parts);
        Console.WriteLine($"После удаления слова - '{str}'");;
        Console.WriteLine($"Самое длинное слово - '{max}'");
        Console.ReadLine();
    }
}
